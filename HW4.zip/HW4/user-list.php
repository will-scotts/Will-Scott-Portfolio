<?php
include 'authorizing.php';

require 'db.php';

// Retrieve all users from the database
$stmt = $conn->prepare("SELECT username, role_id FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User List</title>
</head>
<body>
    <h1>User List</h1>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Role</th>
        </tr>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['username']); ?></td>
                <td><?php echo $user['role_id'] == 1 ? 'Admin' : 'Customer'; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>