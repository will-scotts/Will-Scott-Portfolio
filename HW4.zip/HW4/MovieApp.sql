-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 06, 2024 at 06:44 PM
-- Server version: 8.0.35
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MovieApp`
--

-- --------------------------------------------------------

--
-- Table structure for table `Movie`
--

CREATE TABLE `Movie` (
  `movie_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `director` varchar(100) DEFAULT NULL,
  `release_year` varchar(50) DEFAULT NULL,
  `budget` varchar(50) DEFAULT NULL,
  `runtime` varchar(50) DEFAULT NULL,
  `rating` varchar(50) DEFAULT NULL,
  `genre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Movie`
--

INSERT INTO `Movie` (`movie_id`, `title`, `description`, `director`, `release_year`, `budget`, `runtime`, `rating`, `genre`) VALUES
(2, 'The Dark Knight', 'Batman faces the Joker in Gotham.', 'Christopher Nolan', '2008', '$185M', '152', 'PG-13', 'Action'),
(3, 'Pulp Fiction', 'The lives of two mob hitmen, a boxer, and a pair of robbers intersect.', 'Quentin Tarantino', '1994', '$8M', '154', 'R', 'Crime'),
(4, 'The Matrix', 'A hacker learns about the true nature of reality and his role in the war against its controllers.', 'The Wachowskis', '1999', '$63M', '136', 'R', 'Action'),
(5, 'Fight Club', 'An insomniac forms an underground fight club.', 'David Fincher', '1999', '$63M', '139', 'R', 'Drama'),
(6, 'Interstellar', 'A group of explorers travels through a wormhole in space.', 'Christopher Nolan', '2014', '$165M', '169', 'PG-13', 'Sci-Fi'),
(7, 'The Godfather', 'The aging patriarch of an organized crime dynasty transfers control to his son.', 'Francis Ford Coppola', '1972', '$6M', '175', 'R', 'Crime'),
(8, 'Titanic', 'A love story set during the ill-fated voyage of the Titanic.', 'James Cameron', '1997', '$200M', '195', 'PG-13', 'Romance'),
(9, 'Gladiator', 'A betrayed Roman general seeks revenge against the corrupt emperor.', 'Ridley Scott', '2000', '$103M', '155', 'R', 'Action'),
(10, 'Jurassic Park', 'Dinosaurs run amok in a theme park.', 'Steven Spielberg', '1993', '$63M', '127', 'PG-13', 'Adventure'),
(11, 'Avengers: Endgame', 'The Avengers take a final stand against Thanos.', 'Anthony Russo, Joe Russo', '2019', '$356M', '181', 'PG-13', 'Action'),
(12, 'Forrest Gump', 'A slow-witted man\'s extraordinary journey through life.', 'Robert Zemeckis', '1994', '$55M', '142', 'PG-13', 'Drama'),
(13, 'The Shawshank Redemption', 'Two imprisoned men form a bond over several years.', 'Frank Darabont', '1994', '$25M', '142', 'R', 'Drama'),
(14, 'The Lion King', 'A young lion prince flees his kingdom only to learn the true meaning of responsibility.', 'Roger Allers, Rob Minkoff', '1994', '$45M', '88', 'G', 'Animation'),
(15, 'Goodfellas', 'The story of Henry Hill and his life in the mob.', 'Martin Scorsese', '1990', '$25M', '146', 'R', 'Crime'),
(16, 'Braveheart', 'A Scottish warrior leads a revolt against the English.', 'Mel Gibson', '1995', '$72M', '178', 'R', 'Action'),
(17, 'The Departed', 'An undercover cop and a mole try to identify each other.', 'Martin Scorsese', '2006', '$90M', '151', 'R', 'Crime'),
(18, 'Mad Max: Fury Road', 'In a post-apocalyptic wasteland, Max helps a rebellious woman escape a tyrant.', 'George Miller', '2015', '$150M', '120', 'R', 'Action'),
(19, 'Star Wars: A New Hope', 'Luke Skywalker joins forces with a Jedi Knight to save the galaxy.', 'George Lucas', '1977', '$11M', '121', 'PG', 'Sci-Fi'),
(20, 'Schindler\'s List', 'A businessman saves the lives of more than a thousand Polish Jews during the Holocaust.', 'Steven Spielberg', '1993', '$22M', '195', 'R', 'Drama'),
(21, 'Inception', 'A mind-bending thriller about dreams within dreams', 'Christopher Nolan', '2010', '160000000', '148', 'PG-13', 'Sci-Fi');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `user_id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`user_id`, `username`, `password`, `first_name`, `last_name`, `email`) VALUES
(1, 'john_doe', 'password123', 'John', 'Doe', 'john.doe@example.com'),
(2, 'jane_smith', 'password456', 'Jane', 'Smith', 'jane.smith@example.com'),
(3, 'mark_jones', 'password789', 'Mark', 'Jones', 'mark.jones@example.com'),
(4, 'emily_clark', 'password321', 'Emily', 'Clark', 'emily.clark@example.com'),
(5, 'michael_wright', 'password654', 'Michael', 'Wright', 'michael.wright@example.com'),
(6, 'sarah_king', 'password987', 'Sarah', 'King', 'sarah.king@example.com'),
(7, 'david_lee', 'password135', 'David', 'Lee', 'david.lee@example.com'),
(8, 'laura_miller', 'password246', 'Laura', 'Miller', 'laura.miller@example.com'),
(9, 'daniel_brown', 'password369', 'Daniel', 'Brown', 'daniel.brown@example.com'),
(10, 'nicole_green', 'password753', 'Nicole', 'Green', 'nicole.green@example.com'),
(11, 'james_white', 'password159', 'James', 'White', 'james.white@example.com'),
(12, 'olivia_wood', 'password852', 'Olivia', 'Wood', 'olivia.wood@example.com'),
(13, 'chris_jackson', 'password951', 'Chris', 'Jackson', 'chris.jackson@example.com'),
(14, 'megan_taylor', 'password753', 'Megan', 'Taylor', 'megan.taylor@example.com'),
(15, 'andrew_moore', 'password654', 'Andrew', 'Moore', 'andrew.moore@example.com'),
(16, 'elizabeth_adams', 'password321', 'Elizabeth', 'Adams', 'elizabeth.adams@example.com'),
(17, 'robert_hall', 'password789', 'Robert', 'Hall', 'robert.hall@example.com'),
(18, 'amelia_scott', 'password456', 'Amelia', 'Scott', 'amelia.scott@example.com'),
(19, 'william_thompson', 'password123', 'William', 'Thompson', 'william.thompson@example.com'),
(20, 'sophia_baker', 'password159', 'Sophia', 'Baker', 'sophia.baker@example.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Movie`
--
ALTER TABLE `Movie`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Movie`
--
ALTER TABLE `Movie`
  MODIFY `movie_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
