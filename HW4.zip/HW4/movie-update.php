<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: movie-login.php");
    exit();
}
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: movie-login.php");
    exit();
}

// Include database connection
include 'db_connection.php';

// Check if a movie ID is provided to update
if (isset($_GET['id'])) {
    $movie_id = $_GET['id'];

    // Fetch movie details from the database
    $stmt = $conn->prepare("SELECT title, description FROM movies WHERE id = ?");
    $stmt->bind_param("i", $movie_id);
    $stmt->execute();
    $stmt->bind_result($title, $description);
    $stmt->fetch();
    $stmt->close();
} else {
    echo "Movie ID not provided.";
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get updated data from the form
    $new_title = trim($_POST['title']);
    $new_description = trim($_POST['description']);

    // Update the movie details in the database
    $stmt = $conn->prepare("UPDATE movies SET title = ?, description = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_title, $new_description, $movie_id);

    if ($stmt->execute()) {
        // Redirect to the movie list page after updating
        header("Location: movie-list.php");
        exit();
    } else {
        $error = "Failed to update the movie.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Movie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Update Movie</h1>

    <?php
    // Displays error message if update failed
    if (!empty($error)) {
        echo "<p style='color:red;'>$error</p>";
    }
    ?>

    <form action="movie-update.php?id=<?php echo $movie_id; ?>" method="post">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>"><br><br>
        
        <label for="description">Description:</label>
        <textarea id="description" name="description"><?php echo htmlspecialchars($description); ?></textarea><br><br>
        
        <input type="submit" value="Update Movie">
    </form>
</body>
</html>