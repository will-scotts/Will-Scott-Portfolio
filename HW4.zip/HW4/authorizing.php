<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: movie-login.php");
    exit();
}

// Database connection
require 'db.php';

// Get user role from the session
$user_role = $_SESSION['role'];

// Role-based access logic
$page = basename($_SERVER['PHP_SELF']);
$admin_pages = ['user-list.php']; // Pages accessible only by admins

if (in_array($page, $admin_pages) && $user_role != 'admin') {
    header("Location: unauthorized.php");
    exit();
}
?>