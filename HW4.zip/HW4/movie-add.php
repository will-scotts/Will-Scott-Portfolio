<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: movie-login.php");
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs
    $title = htmlspecialchars($_POST['title']);
    $description = htmlspecialchars($_POST['description']);
    $trailer = htmlspecialchars($_POST['trailer']);
    
    echo "<h1>New Movie Added</h1>";
    echo "<p><strong>Title:</strong> $title</p>";
    echo "<p><strong>Description:</strong> $description</p>";
    echo "<p><strong>YouTube Trailer Link:</strong> <a href='$trailer' target='_blank'>$trailer</a></p>";
    echo "<a href='add-movie.php'>Add Another Movie</a>";
}
?>