<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<?php
// Start session
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: movie-login.php");
    exit();
}

// Check if user is logged in (optional, based on your requirements)
if (!isset($_SESSION['role'])) {
    header("Location: movie-login.php");
    exit();
}

// Check if the movie ID is provided
if (!isset($_GET['id'])) {
    echo "Movie ID not specified.";
    exit();
}

// Get the movie ID from the URL
$movie_id = $_GET['id'];

// Include the database connection
include 'db_connection.php';

try {
    // Prepare a statement to fetch movie details
    $stmt = $conn->prepare("SELECT title, image, description, trailer FROM movies WHERE id = ?");
    $stmt->bind_param("i", $movie_id);
    $stmt->execute();
    $stmt->bind_result($title, $image, $description, $trailer);
    $stmt->fetch();

    // Check if the movie exists
    if (!$title) {
        echo "Movie not found.";
        exit();
    }

    // Close the statement
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    echo "Error retrieving movie details.";
    exit();
}
?>