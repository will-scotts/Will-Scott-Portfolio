<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<?php

// Start the session
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: movie-login.php");
    exit();
}
// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // If the user is not an admin, redirect to the login page
    header("Location: movie-login.php");
    exit();
}

// Check if the movie ID is set in the GET request
if (!isset($_GET['id'])) {
    // If no movie ID is provided, redirect to the movie list
    header("Location: movie-list.php");
    exit();
}

// Get the movie ID from the URL
$movie_id = $_GET['id'];

// Database connection
include 'db_connection.php'; // Assuming db_connection.php contains the DB connection details

try {
    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM movies WHERE id = ?");
    $stmt->bind_param("i", $movie_id);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect to movie-list.php after successful deletion
        header("Location: movie-list.php");
    } else {
        // Redirect to movie-list.php with an error message if deletion failed
        header("Location: movie-list.php?error=deletion_failed");
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    // If an exception occurs, redirect to movie-list.php with an error message
    header("Location: movie-list.php?error=exception");
}
?>