<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<?php
session_start();
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection
    include 'db_connection.php';

    // Retrieve and sanitize input values
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Check if the fields are empty
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        // Prepare a statement to check for user credentials
        $stmt = $conn->prepare("SELECT id, role, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($user_id, $role, $hashed_password);

        // Verify if a user was found and check the password
        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            if (password_verify($password, $hashed_password)) {
                // Set session variables
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;

                // Redirect to the movie list page
                header("Location: movie-list.php");
                exit();
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "Invalid username.";
        }

        // Close statement
        $stmt->close();
    }

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role_id'] == 1 ? 'admin' : 'customer'; // Set role in session
        header("Location: movie-dashboard.php");
        exit();
    }

    // Close database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Login</h1>

    <?php
    // Display an error message if login failed
    if (!empty($error)) {
        echo "<p style='color:red;'>$error</p>";
    }
    ?>

