<?php include 'authorizing.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

// Start the session
session_start();

<?php include 'authorizing.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <a href="movie-logout.php">Logout</a>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Movie List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Movie List</h1>
    <a href="movie-add.php">Add New Movie</a>
    <ul>
        <?php
    
        session_start();
        
        if (!isset($_SESSION['username'])) {
            header("Location: movie-login.php");
            exit();
        }
        // Array of movies - you can replace this with data from a database if needed
        $movies = ["Movie 1", "Movie 2", "Movie 3"];

        // Loop through each movie and create a list item with a link
        foreach ($movies as $movie) {
            echo "<li><a href='movie-details.php'>$movie</a></li>";
        }
        ?>
    </ul>
</body>
</html>